class AttrAccessorObject
  def self.my_attr_accessor(*names)
    # ...
  end
end
